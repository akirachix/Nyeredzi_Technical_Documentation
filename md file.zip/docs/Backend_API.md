# ⚙️ 3. Backend / API

> The engine room of IvhuRedu — where every request from USSD, mobile, and web ends up.

---

## 📑 Table of Contents
- [⚙️ 3. Backend / API](#️-3-backend--api)
  - [📑 Table of Contents](#-table-of-contents)
  - [3.1 API Overview](#31-api-overview)
  - [3.2 Hosted API](#32-hosted-api)
  - [3.3 Prerequisites](#33-prerequisites)
  - [3.4 Setup and Installation](#34-setup-and-installation)
  - [3.5 Architecture Layers](#35-architecture-layers)
  - [3.6 API Conventions](#36-api-conventions)
  - [3.7 Endpoint Categories](#37-endpoint-categories)
  - [3.8 Data Models](#38-data-models)
  - [3.9 Testing and QA](#39-testing-and-qa)
  - [3.10 Code Standards](#310-code-standards)
  - [3.11 Deployment](#311-deployment)

---

## 3.1 API Overview

The IvhuRedu backend is a **REST API** built with **FastAPI**. It is the single point of contact for the web dashboard, the mobile app, and the USSD service — none of them talk to the database directly.

---

## 3.2 Hosted API

| Resource | Link |
|---|---|
| 🔗 Live Swagger Docs | https://ivhuredu-84bcc06bef30.herokuapp.com/docs |

The Swagger UI lets you explore, test, and read details for every endpoint without writing any code.

---

## 3.3 Prerequisites

Before working on the backend, make sure you have:

- Python (matching the project's required version)
- PostgreSQL installed locally or access to a hosted instance
- A `.env` file with the required environment variables (see [7. Deployment](./Deployment.md))
- Access to Africa's Talking, SMS Leopard, and LocationIQ sandbox credentials for local testing

---

## 3.4 Setup and Installation

```bash
# clone the repository
git clone <repository-url>
cd backend

# create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate

# install dependencies
pip install -r requirements.txt

# set up environment variables
cp .env.example .env

# run the development server
uvicorn app.main:app --reload
```

Once running, visit `/docs` on your local server to see the interactive API documentation.

---

## 3.5 Architecture Layers

The backend is organized into clear layers so that code stays easy to find and maintain:

| Layer | Responsibility |
|---|---|
| **Routers** | Define API endpoints and handle requests |
| **Schemas** | Pydantic models used to validate input and shape output |
| **Models** | SQLAlchemy / SQLModel database models |
| **Dependencies** | Shared logic such as authentication checks |

Schemas, models, routers, and dependencies are kept in **separate files** unless they are tightly coupled.

---

## 3.6 API Conventions

- Follows standard **REST conventions**.
- Uses FastAPI's automatically generated **OpenAPI schema**, viewable at `/docs`.
- Naming:
  - `snake_case` for variables, functions, and files.
  - `PascalCase` for classes, Pydantic models, and database models.

---

## 3.7 Endpoint Categories

| Category | Example Endpoints | What it covers |
|---|---|---|
| 🔐 Auth | `/auth/login`, `/auth/change-password`, `/auth/refresh-token`, `/auth/forgot-password`, `/auth/reset-password` | Login, password management, tokens |
| 👤 Users | `/users/` | Create, view, update, delete admins & supervisors |
| 👨‍🌾 Farmers | `/farmers/farmers/` | Register and manage farmer records |
| 🧑‍🔧 Extension Workers | `/extension-workers/extension-workers/` | Register, update, and track worker status |
| 📍 Locations | `/locations/locations/...` | Save, search, geocode, and reverse-geocode locations; find nearby farmers/workers |
| 📨 Farmer Requests | `/farmer-requests/...` | Create, search, assign, and manage farmer assistance requests |
| 🖼️ Field Images | `/field-images/field-images/...` | Upload, download, and manage field report photos |
| 📋 Field Reports | `/field-reports/field-reports/...` | Create and manage field reports |
| 💬 SMS | `/sms/sms/...` | Send SMS/alerts/OTP, view logs and history |
| ☎️ USSD | `/ussd` | Receives USSD session callbacks |
| ❤️ System | `/`, `/health` | Root response and health check |

---

## 3.8 Data Models

The database (PostgreSQL) stores:

- Farmer details
- Extension worker details
- Reports
- Location information
- Assistance requests
- Assignments
- Other system records (users, SMS logs, images)

Every table uses **indexed, UUID-based primary keys**, and location-related tables use **spatial indexes**, to keep lookups fast even as the platform grows.

---

## 3.9 Testing and QA

| Type | Tool |
|---|---|
| Unit & Integration | `pytest` with `httpx.AsyncClient` |
| Coverage | `pytest-cov`, target **>90%** |

Backend tests cover logic, API endpoints, and database operations. See [8. Developer Guide](./Developer_Guide.md) for the full testing strategy.

---

## 3.10 Code Standards

- Validate all input natively with **Pydantic**.
- Handle authentication using **FastAPI security dependencies** (e.g. OAuth2 with JWT).
- Restrict access using **CORSMiddleware** and **TrustedHostMiddleware**.
- Document code using **Python docstrings**.

---

## 3.11 Deployment

| Setting | Value |
|---|---|
| Platform | Heroku (Staging & Production) |
| Server | ASGI (Uvicorn or Gunicorn + Uvicorn workers) |
| Deploy branch | `main` |
| Start command | `web: uvicorn app.main:app --host 0.0.0.0 --port $PORT` |
| Scaling | Automatic, via Heroku dynos |
| Rollback | Redeploy a previous release from the Heroku dashboard |

**Deployment steps:**
1. Development happens on feature branches.
2. Merging to `main` triggers a Heroku deployment.
3. Heroku pulls the latest code and starts the server using the `Procfile`.
4. Environment variables are injected securely at runtime from the Heroku dashboard.
5. Dynos scale automatically based on traffic.
6. If something breaks, roll back to a previous stable release.

---

⬅️ **[2. Architecture](./Architecture.md)** | ➡️ **[4. Frontend Web](./Frontend_Web.md)**