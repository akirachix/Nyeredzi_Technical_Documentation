# 🚀 7. Deployment

> How IvhuRedu's pieces get from a developer's branch to production.

---

## 📑 Table of Contents
- [🚀 7. Deployment](#-7-deployment)
  - [📑 Table of Contents](#-table-of-contents)
  - [7.1 Deployment Architecture](#71-deployment-architecture)
  - [7.2 Backend Deployment](#72-backend-deployment)
  - [7.3 Frontend Deployment](#73-frontend-deployment)
  - [7.4 Mobile Deployment](#74-mobile-deployment)
  - [7.5 External Services](#75-external-services)
  - [7.6 System Integration](#76-system-integration)
  - [7.7 Environment Variables](#77-environment-variables)
    - [Africa's Talking (USSD)](#africas-talking-ussd)
    - [SMS Leopard (SMS)](#sms-leopard-sms)
    - [LocationIQ](#locationiq)
    - [Database](#database)
    - [Adding a New Integration](#adding-a-new-integration)
  - [7.8 CI/CD Pipeline](#78-cicd-pipeline)

---

## 7.1 Deployment Architecture

```
   GitHub (main branch)
          │
          ▼
   ┌──────────────┐
   │   Heroku      │  →  Backend API (FastAPI, Uvicorn)
   └──────────────┘
          │
          ▼
   PostgreSQL Database
```

All backend deployments flow from the `main` branch on GitHub into Heroku.

---

## 7.2 Backend Deployment

| Setting | Value |
|---|---|
| Platform | Heroku (Staging & Production) |
| Server | ASGI — Uvicorn or Gunicorn with Uvicorn workers |
| Deploy branch | `main` |
| Procfile | `web: uvicorn app.main:app --host 0.0.0.0 --port $PORT` |
| Scaling | Automatic, via Heroku dynos |
| Rollback | Redeploy a previous stable release from the Heroku dashboard |

**Steps:**
1. Development happens on feature branches.
2. Merging into `main` triggers a Heroku deployment.
3. Heroku pulls the latest code and starts the ASGI server using the `Procfile`.
4. Environment variables and secrets are injected securely at runtime from the Heroku dashboard.
5. Heroku dynos scale automatically based on live traffic.
6. If something goes wrong, roll back to a previous stable release from the Heroku dashboard.

---

## 7.3 Frontend Deployment

The **informational website** is hosted here:
🔗 https://nyeredzi-informational-website.vercel.app/

> 📌 **Open item:** The exact deployment target and pipeline for the Next.js **dashboard** (as opposed to the informational website) should be documented here once confirmed.

---

## 7.4 Mobile Deployment

> 📌 **Open item:** App distribution details (e.g. Google Play / internal distribution, build signing, and release process) still need to be documented.

---

## 7.5 External Services

| Service | Purpose |
|---|---|
| **Africa's Talking** | USSD and SMS communication for farmers |
| **SMS Leopard** | Sends SMS alerts and notifications |
| **LocationIQ** | Geocoding and location-based lookups |

---

## 7.6 System Integration

The backend is the **only** component that talks directly to external services. The web dashboard and mobile app never call Africa's Talking, SMS Leopard, or LocationIQ directly — every request passes through the backend API first.

---

## 7.7 Environment Variables

### Africa's Talking (USSD)
| Variable | Purpose | Where to get it |
|---|---|---|
| `AT_API_KEY` | Authenticates API calls | AT developer portal (sandbox key for local dev) |
| `AT_USERNAME` | Account identifier | AT developer portal |

> 📌 Confirm the webhook URL registered with Africa's Talking (must be a public HTTPS endpoint — use a tunnel like ngrok for local dev), and confirm only the USSD product is enabled now that SMS runs through SMS Leopard.

### SMS Leopard (SMS)
| Variable | Purpose | Where to get it |
|---|---|---|
| `SMSLEOPARD_API_KEY` | Authenticates SMS send requests | SMS Leopard dashboard |
| `SMSLEOPARD_API_SECRET` | Paired with the API key for authentication | SMS Leopard dashboard |

> 📌 Confirm the exact credential field names expected by the SMS Leopard API, the sender ID configured for IvhuRedu, and whether a delivery-status webhook needs to be registered.

### LocationIQ
| Variable | Purpose | Where to get it |
|---|---|---|
| `LOCATIONIQ_API_KEY` | Authenticates geocoding requests | LocationIQ dashboard |

> 📌 Confirm the plan/tier in use and its rate limit, so local development doesn't unexpectedly hit it during testing.

### Database
> 📌 Define the `DATABASE_URL` format and any PostgreSQL-specific setup (required extensions, connection pooling configuration).

### Adding a New Integration
> 📌 Team convention to document: add the credential to `.env.example` with a placeholder value, document it here in the same table format, and add a troubleshooting row once a real failure has been seen.

---

## 7.8 CI/CD Pipeline

- **GitHub** is used for version control and collaborative development.
- Code changes go through **pull requests** and are reviewed before merging.
- Tests, linting, and formatting checks should pass before a PR is merged.
- Automated CI/CD pipelines should only be documented here **once they are actually configured** for a given component.

---

⬅️ **[6. Security](./Security.md)** | ➡️ **[8. Developer Guide](./Developer_Guide.md)**