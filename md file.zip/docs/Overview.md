# 📖 1. Overview

> **IvhuRedu** — *"Our Soil"*
> Connecting Farmers and Agritex Officers for Better Land Management

---

## 📑 Table of Contents
- [📖 1. Overview](#-1-overview)
  - [📑 Table of Contents](#-table-of-contents)
  - [1.1 Product Definition](#11-product-definition)
  - [1.2 Problem Statement](#12-problem-statement)
  - [1.3 Target Users](#13-target-users)
  - [1.4 Key Features](#14-key-features)
  - [1.5 Workflow Overview](#15-workflow-overview)

---

## 1.1 Product Definition

**IvhuRedu** is a digital agricultural platform that connects **farmers** and **Agritex officers** (agricultural extension workers) to make it easier to collect, share, manage, and monitor agricultural information.

It brings together three ways of reaching people, all talking to one shared system:

| Channel | Who uses it | How they connect |
|---|---|---|
| 📱 USSD | Farmers | Basic mobile phone — no smartphone or internet needed |
| 📲 Mobile App | Agritex Extension Workers | Flutter app for field work |
| 💻 Web Dashboard | Administrators & Supervisors | Next.js dashboard for oversight |

All three channels are connected through one **backend API** and one **database**, so information collected in the field ends up in the same central system.

---

## 1.2 Problem Statement

Many farmers do not own a smartphone or have reliable internet access, which makes it hard for them to:

- Ask for help from an agricultural extension officer.
- Report problems in their fields, such as land degradation, pests, or disease.
- Receive timely advice and support.

At the same time, Agritex officers and supervisors need a simple, centralized way to:

- Know which farmers need help and where they are located.
- Track field visits, reports, and worker assignments.
- Monitor land conditions across many wards at once.

**IvhuRedu solves this gap** by giving farmers a phone-based way in (USSD), giving officers a mobile tool for field work, and giving supervisors a dashboard to see and manage everything in one place.

---

## 1.3 Target Users

| User Type | Access Point | What they do |
|---|---|---|
| 👨‍🌾 **Farmer** | USSD (basic phone) | Requests help, reports land issues, receives SMS alerts |
| 🧑‍🔧 **Extension Worker** | Mobile App (Flutter) | Manages farmers, visits, and field reports |
| 🧑‍💼 **Supervisor** | Web Dashboard | Manages extension workers, assigns requests, sends alerts |
| 🛡️ **Administrator** | Web Dashboard | Manages supervisors and overall system users |

---

## 1.4 Key Features

- **📞 USSD Farmer Access** — Farmers reach the platform on any basic phone.
- **📝 Digital Field Reporting** — Reports are collected and stored digitally instead of on paper.
- **📲 Agritex Mobile Application** — Extension workers manage farmers and field activity on the go.
- **🌾 Farmer & Field Management** — A central place to keep farmer and field records.
- **📸 Field Image Collection** — Photos can be attached as evidence to field reports.
- **📊 Web Dashboard** — One screen to monitor everything happening across the platform.
- **🔗 Connected Platform** — USSD, mobile, and web all share the same backend and database.

---

## 1.5 Workflow Overview

```
 Farmer (USSD)                Extension Worker (Mobile App)
       │                                 │
       ▼                                 ▼
 ┌─────────────────────────────────────────────┐
 │              Backend REST API                │
 └─────────────────────────────────────────────┘
                       │
                       ▼
              PostgreSQL Database
                       ▲
                       │
              Web Dashboard (Supervisors/Admins)
```

1. A **farmer** dials in through USSD and submits a request (e.g. "please send someone to look at my field").
2. The request reaches the **backend API** and is saved to the **database**.
3. A **supervisor** sees the new request on the **web dashboard** and assigns it to an **extension worker**.
4. The **extension worker** visits the field using the **mobile app**, submits a report (with photos and location), and updates the request status.
5. The **supervisor** monitors progress and can send **SMS alerts** back to the farmer.

---

⬅️ *This is Page 1 of 8.* ➡️ Continue to **[2. Architecture](./Architecture.md)**