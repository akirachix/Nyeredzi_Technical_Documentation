# 🔒 6. Security

> How IvhuRedu protects its users, data, and systems.

---

## 📑 Table of Contents
- [🔒 6. Security](#-6-security)
  - [📑 Table of Contents](#-table-of-contents)
  - [6.1 Security Posture](#61-security-posture)
  - [6.2 Data Classification](#62-data-classification)
  - [6.3 Network Security](#63-network-security)
  - [6.4 Application Security](#64-application-security)
  - [6.5 Data Security](#65-data-security)
  - [6.6 Webhook Security](#66-webhook-security)
  - [6.7 Physical Security](#67-physical-security)
  - [6.8 Incident Response](#68-incident-response)
  - [6.9 Risk Management](#69-risk-management)
  - [6.10 Conclusion](#610-conclusion)

---

## 6.1 Security Posture

IvhuRedu uses **role-based access control (RBAC)** so that every user — Administrator, Supervisor, Extension Worker, or Farmer — can only access the information and actions their role allows. Authentication is required before any protected functionality can be used, on both the web dashboard and the mobile app.

---

## 6.2 Data Classification

| Data Type | Examples | Sensitivity |
|---|---|---|
| Credentials | Passwords, tokens, OTP codes | 🔴 High |
| Personal Data | Farmer and worker contact/location details | 🟠 Medium–High |
| Operational Data | Reports, assignments, field images | 🟡 Medium |
| Configuration Secrets | API keys (Africa's Talking, SMS Leopard, LocationIQ) | 🔴 High |

Test data used during development should use **synthetic or test accounts**, avoiding unnecessary real personal information.

---

## 6.3 Network Security

- **CORSMiddleware** and **TrustedHostMiddleware** restrict which origins and hosts can talk to the backend.
- Webhooks (e.g. from Africa's Talking) must use a **publicly reachable HTTPS endpoint**.
- Local development uses a tunnel (such as ngrok) to safely expose a local server for webhook testing.

---

## 6.4 Application Security

- All input is validated natively using **Pydantic** models on the backend.
- Authentication is handled through **FastAPI security dependencies** (e.g. OAuth2 with JWT tokens).
- Access to dashboard and mobile functionality is enforced according to the user's **role and permissions**.
- Expired sessions require the user to **log in again** before continuing.

---

## 6.5 Data Security

- All **tokens, passwords, and PIN codes are encrypted at rest**.
- Sensitive configuration values (API keys, secrets, credentials) are stored in **environment variables**, never committed to source control.
- `.env` files are excluded from source control using `.gitignore`.
- Logs must **never** expose passwords, API keys, or other sensitive information.

---

## 6.6 Webhook Security

| Integration | Webhook Requirement |
|---|---|
| Africa's Talking (USSD) | Must be a publicly reachable HTTPS endpoint — confirm the registered webhook URL and that only the USSD product is enabled |
| SMS Leopard | Delivery-status webhook (if used) still needs to be confirmed and documented |

> 📌 **Open item:** The exact webhook URL registered with Africa's Talking still needs to be confirmed, along with whether a delivery-status webhook is required for SMS Leopard.

---

## 6.7 Physical Security

The platform's infrastructure (backend, database) is hosted on **Heroku**, which manages the physical security of the underlying servers. The IvhuRedu team is responsible for securing accounts, credentials, and access to the Heroku dashboard itself.

---

## 6.8 Incident Response

**Monitoring**
- Backend API errors and application failures
- Database errors and failed requests
- USSD and SMS communication issues

**Logging**
- Backend errors and important events are logged for troubleshooting
- Logs never expose sensitive information

**Alerting**
- Administrators are notified of critical failures where alerting is configured
- Failed external service requests are investigated and handled appropriately

---

## 6.9 Risk Management

Known open risk items that need follow-up:

- ⚠️ Confirm the webhook URL registered with Africa's Talking and that only the USSD product is enabled (SMS now runs through SMS Leopard).
- ⚠️ Confirm the exact credential field names SMS Leopard expects, the sender ID for IvhuRedu, and whether a delivery-status webhook is required.
- ⚠️ Confirm the LocationIQ plan/tier and its rate limit, to avoid unexpectedly hitting limits during local testing.
- ⚠️ Define the `DATABASE_URL` format and any required PostgreSQL extensions or connection pooling configuration.

---

## 6.10 Conclusion

Security in IvhuRedu is built on three habits: **never commit secrets**, **encrypt sensitive data at rest**, and **only give users access to what their role needs**. These principles apply equally across the backend, web dashboard, and mobile app.

---

⬅️ **[5. Frontend Mobile](./Frontend_Mobile.md)** | ➡️ **[7. Deployment](./Deployment.md)**