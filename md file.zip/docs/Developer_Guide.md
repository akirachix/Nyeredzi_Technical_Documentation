# 🛠️ 8. Developer Guide

> Rules and conventions every contributor should follow.

---

## 📑 Table of Contents
- [🛠️ 8. Developer Guide](#️-8-developer-guide)
  - [📑 Table of Contents](#-table-of-contents)
  - [8.1 Global Code Standards](#81-global-code-standards)
    - [Naming](#naming)
    - [Documentation](#documentation)
    - [Best Practices](#best-practices)
    - [Branding \& Design](#branding--design)
    - [Accessibility \& Values](#accessibility--values)
  - [8.2 Testing Conventions](#82-testing-conventions)
  - [8.3 Git Workflow](#83-git-workflow)
  - [8.4 Glossary](#84-glossary)

---

## 8.1 Global Code Standards

### Naming
| Component | Standard |
|---|---|
| Backend (Python) | `snake_case` for variables, functions, files; `PascalCase` for classes, Pydantic, and database models |
| Frontend (React) | Prettier + ESLint |
| Mobile (Flutter/Dart) | `dart format` + `flutter analyze` |

### Documentation
| Component | Standard |
|---|---|
| Frontend | JSDoc |
| Mobile | Dartdoc |
| Backend | Python docstrings |

### Best Practices
- Keep functions and components **small, focused, and reusable**.
- Avoid committing **commented-out code**.
- Refactor and remove **unused code** regularly.
- Always **run tests** before pushing or merging.
- Use **environment variables** for secrets — never commit credentials, database URLs, or API keys.
- Ensure PostgreSQL queries and ORM operations use **indexed, UUID-based primary keys** for performance.
- Update the **README and feature docs** for all changes.

### Branding & Design
- Follow the **IvhuRedu Brand Guidelines** for colors, typography, and logos.
- Keep the UI consistent with the team's **Figma designs**.

### Accessibility & Values
- All interfaces must be usable by **keyboard**, **screen reader**, and on **low-bandwidth devices** (including USSD).
- Code and UI decisions should reflect IvhuRedu's core values: **Rural Resilience**, **Data Integrity**, and **Accessibility**.

---

## 8.2 Testing Conventions

| Layer | Approach |
|---|---|
| Backend | Unit & integration tests with `pytest` + `httpx.AsyncClient`, targeting **>90% coverage** |
| Frontend | Component and functionality tests, run with `npm test` |
| Mobile | Flutter unit and widget tests, run with `flutter test` |
| API | Endpoint validation and integration testing |
| Usability | Testing directly with farmers and Agritex users |

**Test scenarios to always cover:**
- ✅ Valid inputs
- ❌ Invalid or incomplete inputs
- 👥 Different user roles and permissions
- 🔁 Successful and failed API requests
- 📴 USSD session interruptions
- 🌐 Network and connectivity issues
- 🗄️ Database errors and unavailable services

**Release readiness checklist:**
- [ ] Critical functionality passes testing
- [ ] API tests pass
- [ ] Mobile app tests pass
- [ ] Web app tests pass
- [ ] USSD workflows pass their required scenarios
- [ ] No critical or unresolved blocking defects
- [ ] Authentication and authorization work correctly
- [ ] Data is correctly stored and retrieved
- [ ] Required usability testing is complete
- [ ] Code review is complete
- [ ] Formatting and linting checks pass

---

## 8.3 Git Workflow

1. Team members work on **separate feature or task branches**.
2. Changes are tested locally before being submitted for review.
3. Completed work is pushed to **GitHub**.
4. A **pull request** is opened; related contributions from different team members may be combined into one PR.
5. Every PR needs a **clear description** and links to related issues where applicable.
6. **At least three reviewers** must review before merging.
7. Reviewers check functionality, code quality, testing, formatting, and adherence to project standards.
8. Tests, linting, and formatting are verified **before** merging.
9. Approved changes are merged into `main`.

---

## 8.4 Glossary

| Term | Meaning |
|---|---|
| **Agritex** | Agricultural extension services / officers who support farmers |
| **USSD** | Unstructured Supplementary Service Data — a phone-based menu system that works without internet |
| **Extension Worker** | A field officer who visits farmers, submits reports, and manages assigned activities |
| **Supervisor** | A dashboard user who manages Extension Workers and farmer requests |
| **Administrator** | A dashboard user who manages Supervisors and overall system users |
| **Ward** | A geographic area used to organize farmers, workers, and assignments |
| **Farmer Request** | A request submitted by a farmer via USSD (e.g. visit request, advice request, land degradation report) |
| **Field Report** | A record submitted by an Extension Worker describing conditions found during a field visit |
| **Assignment** | A task or request given to a specific Extension Worker |
| **RBAC** | Role-Based Access Control — restricting what a user can see/do based on their role |

---

⬅️ **[7. Deployment](./Deployment.md)** | 🏠 **[Back to 1. Overview](./Overview.md)**