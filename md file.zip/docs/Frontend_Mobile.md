# 💻 4. Frontend Web

> The web dashboard used by Administrators and Supervisors.

---

## 📑 Table of Contents
- [💻 4. Frontend Web](#-4-frontend-web)
  - [📑 Table of Contents](#-table-of-contents)
  - [4.1 Overview](#41-overview)
  - [4.2 Technology Stack](#42-technology-stack)
  - [4.3 Prerequisites](#43-prerequisites)
  - [4.4 Setup and Installation](#44-setup-and-installation)
  - [4.5 Project Structure](#45-project-structure)
  - [4.6 Coding Standards](#46-coding-standards)
  - [4.7 Authentication Flow](#47-authentication-flow)
  - [4.8 API Integration](#48-api-integration)
  - [4.9 Pages and Features](#49-pages-and-features)
    - [👥 User Management](#-user-management)
    - [📊 Analytics](#-analytics)
    - [📨 Farmer Request](#-farmer-request)
    - [📣 SMS Alerts](#-sms-alerts)
    - [⚙️ Settings](#️-settings)
  - [4.10 Styling](#410-styling)
  - [4.11 Error Handling](#411-error-handling)
  - [4.12 QA Documentation](#412-qa-documentation)
  - [4.13 Deployment](#413-deployment)

---

## 4.1 Overview

The IvhuRedu web dashboard is used by **Administrators** and **Supervisors** to manage users, monitor agricultural information, manage farmer requests, send SMS alerts, and manage settings.

> ⚠️ **Note:** Extension Field Workers do **not** use the web dashboard — they use the [Flutter mobile app](./Frontend_Mobile.md) instead.

---

## 4.2 Technology Stack

| Piece | Technology |
|---|---|
| Framework | Next.js |
| Linting | ESLint + Prettier |
| Documentation | JSDoc |

---

## 4.3 Prerequisites

- Node.js and npm installed
- Access to the backend API (local or hosted)
- `.env` file with the required frontend configuration values

---

## 4.4 Setup and Installation

```bash
# clone the repository
git clone <repository-url>
cd web

# install dependencies
npm install

# set up environment variables
cp .env.example .env.local

# start the development server
npm run dev
```

Useful commands:

```bash
npm test        # run frontend tests
npm run format  # check code formatting
```

---

## 4.5 Project Structure

```
web/   →  Next.js web application and dashboard
```

The `web/` directory contains the full dashboard used by Administrators and Supervisors.

---

## 4.6 Coding Standards

- **Linting:** Prettier + ESLint.
- **Documentation:** JSDoc comments for components and functions.
- Keep components **small, focused, and reusable**.
- Update the README and feature docs whenever you make changes.

---

## 4.7 Authentication Flow

1. Administrators and Supervisors log in with their registered credentials.
2. A valid session issues an **authentication token**, used for all protected API calls.
3. If a session expires, the user is asked to **log in again**.
4. Passwords can be changed at any time from **Settings → Change Password**.

---

## 4.8 API Integration

The dashboard communicates with the backend through **REST APIs** for:

- User management
- Extension Field Worker management
- Farmer request management
- Field report retrieval
- Analytics data retrieval
- SMS management
- Profile and password management

```
Web Dashboard  →  Backend API  →  PostgreSQL Database
```

---

## 4.9 Pages and Features

The dashboard has **five main navigation sections**:

### 👥 User Management
- **Administrators** register and manage Supervisors.
- **Supervisors** register and manage Extension Field Workers, assign them to wards, and view their availability.

### 📊 Analytics
- Total registered farmers
- Field visits
- Disease and pest reports
- Crop distribution
- Ward-level analysis
- Harvest and yield information
- Sustainability and land restoration information
- Extension Worker engagement
- GPS visit information

### 📨 Farmer Request
- View, search, and filter incoming farmer requests (`Pending`, `In Progress`, `Resolved`)
- View farmer and location details
- Assign requests to Extension Field Workers
- Track progress and monitor resolution

### 📣 SMS Alerts
- Send individual, broadcast, or ward-based SMS messages
- Monitor delivery status
- View SMS history

### ⚙️ Settings
| Tab | Contents |
|---|---|
| General | User role, default date range, refresh interval |
| Profile | Name, email, phone number, role |
| Change Password | Current, new, and confirm password |
| Display | Real-time data, chart labels, compact view |
| Notifications | Alerts, broadcasts, system notifications |
| Account | Logout |

---

## 4.10 Styling

The dashboard follows the **IvhuRedu Brand Guidelines**:
- Soil Brown for navigation and headers
- Vegetation Green for primary actions
- Sun Gold / Amber for warnings and pending statuses
- **Inter** typeface throughout

---

## 4.11 Error Handling

| Type | Behaviour |
|---|---|
| Form validation | Required fields are checked before submission |
| Authentication errors | User is asked to log in again after session expiry |
| Authorization errors | Users are blocked from actions outside their role |
| API errors | A clear error message is shown when a request fails |
| Success feedback | A confirmation message is shown after a successful action |

---

## 4.12 QA Documentation

Testing covers:
- Component testing
- Form validation testing
- Authentication testing
- Role and permission testing
- API integration testing
- User Management, Farmer Request, and SMS Alerts testing
- Settings testing
- Responsive interface testing
- Usability testing

---

## 4.13 Deployment

The dashboard is built with Next.js and deployed as part of the wider IvhuRedu platform. See [7. Deployment](./Deployment.md) for environment variables and release steps shared across the platform.

---

⬅️ **[3. Backend / API](./Backend_API.md)** | ➡️ **[5. Frontend Mobile](./Frontend_Mobile.md)**