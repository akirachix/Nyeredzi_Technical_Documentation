# 🏗️ 2. Architecture

> How the different pieces of IvhuRedu fit together.

---

## 📑 Table of Contents
- [🏗️ 2. Architecture](#️-2-architecture)
  - [📑 Table of Contents](#-table-of-contents)
  - [2.1 Core Principles](#21-core-principles)
  - [2.2 System Diagram](#22-system-diagram)
  - [2.3 Component Breakdown](#23-component-breakdown)
    - [Integrations](#integrations)
    - [Backend Modules](#backend-modules)
  - [2.4 Data Flow](#24-data-flow)
  - [2.5 Design Guidelines](#25-design-guidelines)
  - [2.6 Scalability Strategy](#26-scalability-strategy)

---

## 2.1 Core Principles

IvhuRedu's architecture is built around a few simple ideas:

- **📵 Accessibility first** — Farmers should not need a smartphone or internet to use the platform, so USSD is the primary farmer channel.
- **🗄️ One source of truth** — All channels (USSD, mobile, web) read and write to the same backend and database, so information never gets out of sync.
- **🔐 Role-based access** — Every user only sees and does what their role allows (Administrator, Supervisor, Extension Worker, Farmer).
- **🧩 Separation of concerns** — Each part of the system (frontend, mobile, USSD, backend) has one clear job.
- **🔌 Pluggable integrations** — External services (SMS, location) are connected through the backend, not built directly into the frontend or mobile apps.

---

## 2.2 System Diagram

```
                     ┌───────────────────────┐
                     │   Farmers (USSD)      │
                     └───────────┬───────────┘
                                 │  Africa's Talking (USSD/SMS)
                                 ▼
┌────────────────┐     ┌───────────────────────┐     ┌────────────────────┐
│  Web Dashboard  │◄───►│   Backend REST API     │◄───►│  Mobile App (Flutter) │
│   (Next.js)     │     │      (FastAPI)         │     │  Agritex Workers      │
└────────────────┘     └───────────┬───────────┘     └────────────────────┘
                                 │
                                 ▼
                     ┌───────────────────────┐
                     │  PostgreSQL Database  │
                     └───────────────────────┘
                                 │
                  ┌──────────────┴──────────────┐
                  ▼                              ▼
          LocationIQ (Geolocation)     SMS Leopard (SMS alerts)
```

---

## 2.3 Component Breakdown

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend (Web)** | Next.js | Dashboard for Agritex Officers and Supervisors |
| **Mobile** | Flutter | App for Agritex Extension Workers in the field |
| **USSD Service** | Africa's Talking | Lets farmers access IvhuRedu with any mobile phone |
| **Backend** | FastAPI (REST API) | Connects every channel to the database |
| **Database** | PostgreSQL | Stores farmers, workers, reports, locations, requests, assignments |

### Integrations
- **Africa's Talking** — USSD and SMS communication.
- **SMS Leopard** — Sends SMS notifications and alerts.
- **LocationIQ** — Geocoding and location lookup.

### Backend Modules
- Assistance Module
- Reporting Module
- Location Module
- Assignment Module
- SMS Alert Module

---

## 2.4 Data Flow

```
Web Dashboard  ──┐
Mobile App     ──┼──►  Backend API  ──►  PostgreSQL Database
USSD Service   ──┘
```

All requests — whether they come from a farmer's phone, an extension worker's app, or a supervisor's dashboard — pass through the **same backend API**, which is the only part of the system allowed to talk to the database directly. This keeps data consistent and secure.

---

## 2.5 Design Guidelines

All interfaces (web, mobile, and USSD messaging) follow the **IvhuRedu Brand Guidelines**:

- **Soil Brown** — headers, navigation, and land-related elements.
- **Vegetation Green** — primary actions and success states.
- **Sun Gold / Amber** — warnings and pending statuses.
- **Typeface** — Inter, used consistently across web and mobile.

👉 See the full **Brand Guideline Reference** for colors, logo usage, and iconography rules.

---

## 2.6 Scalability Strategy

- The backend is deployed on **Heroku**, which automatically scales **dynos** up or down based on live traffic.
- The database uses **indexed UUID primary keys** and spatial indexes to keep queries fast as data grows.
- Stateless API design means multiple backend instances can run at the same time without conflict.
- Rollbacks to a previous stable release can be triggered directly from the Heroku dashboard if a deployment causes issues.

---

⬅️ **[1. Overview](./Overview.md)** | ➡️ **[3. Backend / API](./Backend_API.md)**